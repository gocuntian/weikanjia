<pre>
├── index.php                      首页控制器 
├── install.php                    自动插入配置文件， 注意配置成功后请删除此文件
├── log                            打印的日志文件放 
├── log_.php                       打印log文件 的类
├── readme.txt                     说明文档
├── theme                          所有表态文件 图片 css js
│   ├── css
│   │   └── kanjia.css
│   └── images
│       ├── axe.png
│       ├── dui.png
│       ├── img01.jpg
│       ├── img02.jpg
│       ├── img03.jpg
│       ├── true.png
│       ├── tu1.jpg
│       ├── weixin.jpg
│       ├── zhifu.jpg
│       ├── zh_phone.png
│       └── zh_zuo.png
├── upload                        上传的证书放置区
│   ├── apiclient_cert.pem        支付证书1
│   └── apiclient_key.pem         支付证书2
├── wxauth.php                    通用微信授权接口
├── wxnotify.php                  微信支付异步通知接口
├── wxpayapi.php                  通用微信支付接口
├── wxpayapizero.php              跳转到零元支付接口
└── WxPayPubHelper                微信 idea 公用类
    ├── SDKRuntimeException.php
    ├── Util.idea0086.php
    ├── WxPay.pub.config.php      自动生成的配置文件
    └── WxPayPubHelper.php

6 directories, 27 files 22
</pre>
